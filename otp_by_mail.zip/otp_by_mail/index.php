<?php session_start(); ?>
<?php
    include('connection.php');

    if(isset($_POST["register"])){
        $email = $_POST["email"];
        $name = $_POST["name"];
		$mobile = $_POST["mobile"];
		$course = $_POST["course"];
		//connect ur databse to check whether email already exist or not.
		//e.g-->
        // $check_query = mysqli_query($connect, "SELECT * FROM user where email ='$email'");
        $rowCount = mysqli_num_rows($check_query);

        if(!empty($email) && !empty($name)){
            if($rowCount > 0){
                ?>
                <script>
                    alert("User with email already exist!");
                </script>
                <?php
            }else{
				// if fresh account request for otp then insert it into ur database.
                // e.g -->  $result = mysqli_query($connect, "INSERT INTO (table name) (email, name, mobile, course ,status) VALUES ('$email', '$name', '$mobile', '$course' ,0)");
    
                if($result){
                    $otp = rand(100000,999999);
                    $_SESSION['otp'] = $otp;
                    $_SESSION['mail'] = $email;
                    require "Mail/phpmailer/PHPMailerAutoload.php";
                    $mail = new PHPMailer;
    
                    $mail->isSMTP();
                    $mail->Host='(If email hosted by Hostinger then set) -->(smtp.hostinger.com) if personal then (smtp.gmail.com)';
                    $mail->Port=465;
                    $mail->SMTPAuth=true;
                    $mail->SMTPSecure='(if you use your personal email then set it (tls) or your port name, if any hosted email(hostinger) then set it (ssl))';
    
                    $mail->Username='(email-ID)';
                    $mail->Password='(Password)';
    
                    $mail->setFrom('UR Email-ID', 'Name by which email will send');
                    $mail->addAddress($_POST["email"]);
    
                    $mail->isHTML(true);
                    $mail->Subject="Your OTP verification code";
                    $mail->Body="<p>Dear user, </p> <h3>Your verify OTP code is $otp <br></h3>
                    <br><br>
                    <p>With regrads,</p>
                    <b>Rimanshu.....</b>";
    
                            if(!$mail->send()){
                                ?>
                                    <script>
                                        alert("<?php echo "Register Failed, Invalid Email "?>");
                                    </script>
                                <?php
                            }else{
                                ?>
                                <script>
                                    alert("<?php echo "Register Successfully, OTP sent to " . $email ?>");
                                    window.location.replace('verification.php');
                                </script>
                                <?php
                            }
                }
            }
        }
    }

?>

<!DOCTYPE html>
<html lang="en" >
<head>
  	<meta charset="UTF-8">
  	<title>OTP-Verification</title>
  	<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/normalize/5.0.0/normalize.min.css"> 
	<link rel="stylesheet" href="style.css">

    <!-- Required meta tags -->
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">

    <!-- Fonts -->
	<link rel="preconnect" href="https://fonts.googleapis.com">
	<link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
	<link href="https://fonts.googleapis.com/css2?family=Montserrat:wght@300&family=Pangolin&family=Raleway:wght@500&family=Roboto&display=swap" rel="stylesheet">
    <link rel="icon" href="Favicon.png">

    <!-- Bootstrap js -->
	 <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@4.0.0/dist/css/bootstrap.min.css" integrity="sha384-Gn5384xqQ1aoWXA+058RXPxPg6fy4IWvTNh0E263XmFcJlSAwiGgFAW/dAiS6JXm" crossorigin="anonymous">
</head>
<body>

	<div class="top">
		<img class="logo" src="img/logo-Rim.png" alt="Logo"/>
	</div>
	<hr>
	<div class="container-fluid justify-content-center align-items-center">
		<div class="address">
			<center>
				<h1 style="color: white">SEND OTP BY EMAIL AND VERIFY</h1><br>
				<h3>Connect Verify and form by sending OTP.</h3>
				<h5>Verify it free.</h5><br>
				<h5>Without any Extra Charges.<br><br>

					Most affordable prices for the first batch of Enrollees</h5>
			</center>
		</div>
		<!-- // FORM
		-------------------------------------------------------------
		------------------------------------------------------------>
		<div class="cotainer">
			<div class="row justify-content-center">
				<!-- <div class="col-md-8"> -->
					<div class="card">
						<div class="card-header">OTP Verification by Mail</div>
						<div class="card-body">
							<form action="#" method="POST" name="register">
								<div class="form-group row">
									<label for="email_address" class="col-md-3 col-form-label text-md-right">E-Mail</label>
									<div class="form-w">
										<input type="text" id="email_address" class="form-control" name="email" required autofocus>
									</div>
								</div>

								<div class="form-group row">
									<label for="name" class="col-md-3 col-form-label text-md-right">Name</label>
									<div class="form-w">
										<input type="text" id="name" class="form-control" name="name" required>
										<i class="bi bi-eye-slash" id="togglePassword"></i>
									</div>
								</div>
								<div class="form-group row">
									<label for="mobile" class="col-md-3 col-form-label text-md-right">Phone</label>
									<div class="form-w">
										<input type="text" id="mobile" class="form-control" name="mobile" required>
									</div>
								</div>
								<div class="form-group row">
									<label for="course" class="col-md-3 col-form-label text-md-right">Courses</label>
										<select id="course" class="col-md-8  form-control" name="course">
										<option value="NEET">NEET</option>
										<option value="JEE">JEE</option>
										<option value="12th">12th</option>
										<option value="11th">11th</option>
										</select>
								</div>
								<div class="col-md-6 offset-md-3 my-3">
									<input type="submit" value="Register" name="register">
								</div>
						</div>
						</form>
					</div>
				<!-- </div> -->
			</div>
		</div>
	</div>
	
</div>
	<div class="bottom">
		<p style="margin-top: 20px;">Design and Developed by <a href="https://www.linkedin.com/in/rimanshusingh/">Rimanshu Singh</a></p>
	</div>

</body>
</html>


